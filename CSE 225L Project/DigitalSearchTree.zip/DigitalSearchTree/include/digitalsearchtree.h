#ifndef DIGITALSEARCHTREE_H_INCLUDED
#define DIGITALSEARCHTREE_H_INCLUDED
#include <bitset>
using namespace std;
#include "quetype.h"

template <class DataType>
class DigitalSearchTree
{
private:
    struct tree_node
    {
        tree_node* left;
        tree_node* right;
        DataType data;
    };
    tree_node* root;
    void fillInOrder(QueType<int>&,tree_node*);
    void makeEmpty(tree_node*&);
    void inorder(tree_node*);

public:
    DigitalSearchTree();
    virtual ~DigitalSearchTree();
    bool isEmpty();
    void insert(DataType);
    bool search(DataType);
    void remove(DataType);
    void print_inorder();
    void getInOrder(QueType<int>&);
    void counter(int*, tree_node*);
    int countNode();

};

#endif // DIGITALSEARCHTREE_H_INCLUDED
